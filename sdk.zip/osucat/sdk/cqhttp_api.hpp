#pragma once
#ifndef CQHTTP_API
#define CQHTTP_API

using json = nlohmann::json;

char wsfulladdress[1024];
char wshost[64];
int wsport;
static easywsclient::WebSocket::pointer gwsp = NULL;

std::unique_ptr<easywsclient::WebSocket> gwsp1;

namespace cqhttp_api {

	enum class Type {
		INVALID,
		MESSAGE,
		REQUEST,
	};

	struct Target {
		enum class Type {
			PRIVATE,
			GROUP,
		};
		Type type;
		int64_t time;
		int64_t group_id;
		int64_t user_id;
		int64_t message_id;
		std::string message;
	};

	struct Request {
		enum class Type {
			FRIEND,
			GROUP,
		};
		std::string SubType;
		Type type;
		int64_t time;
		int64_t group_id;
		int64_t user_id;
		std::string flag;
		std::string message;//������Ϣ
	};

	struct GroupSender {
		enum class Role {
			OWNER,
			ADMIN,
			MEMBER,
		};
		int age;
		Role role;
		std::optional<std::string> card; //Ⱥ�ǳ�
		std::string level;
		std::string nickname; //ԭ���û���
		std::optional<std::string> title; //ͷ��
		std::string sex;
	};

	struct PictureInfo {
		int32_t size; //ͼƬ��С
		std::string filename; //ԭʼ�ļ���
		std::string url; //ͼƬ���ص�ַ
		std::string format; //ͼƬ��ʽ .jpg .png .bmp .gif
	};



	void send(json j) {
		gwsp->send(j.dump());
	}

	void send_private_message(Target tar, const std::string msg) {
		tar.message = msg;
		json j;
		std::string tmp;
		j["action"] = "send_private_msg";
		j["params"]["user_id"] = tar.user_id;
		tar.message.empty() ? j["params"]["message"] = "null" : j["params"]["message"] = tar.message;
		tmp += u8"[" + utils::unixTime2Str(time(NULL)) + u8"] [osucat][��]: ���������� " + to_string(tar.user_id) + u8"����Ϣ��";
		tmp += tar.message;
		std::cout << tmp << std::endl;
		send(j);
	}

	void send_group_message(Target tar, const std::string msg) {
		tar.message = msg;
		json j;
		std::string tmp;
		j["action"] = "send_group_msg";
		j["params"]["group_id"] = tar.group_id;
		tar.message.empty() ? j["params"]["message"] = "null" : j["params"]["message"] = tar.message;
		tmp += u8"[" + utils::unixTime2Str(time(NULL)) + u8"] [osucat][��]: ������Ⱥ " + to_string(tar.group_id) + u8"����Ϣ��";
		tmp += tar.message;
		std::cout << tmp << std::endl;
		send(j);
	}

	void send_private_message(int64_t user_id, const std::string msg) {
		json j;
		std::string tmp;
		j["action"] = "send_private_msg";
		j["params"]["user_id"] = user_id;
		msg.empty() ? j["params"]["message"] = "null" : j["params"]["message"] = msg;
		tmp += u8"[" + utils::unixTime2Str(time(NULL)) + u8"] [osucat][��]: ���������� " + to_string(user_id) + u8"����Ϣ��";
		tmp += msg;
		std::cout << tmp << std::endl;
		send(j);
	}

	void send_group_message(int64_t group_id, const std::string msg) {
		json j;
		std::string tmp;
		j["action"] = "send_group_msg";
		j["params"]["group_id"] = group_id;
		msg.empty() ? j["params"]["message"] = "null" : j["params"]["message"] = msg;
		tmp += u8"[" + utils::unixTime2Str(time(NULL)) + u8"] [osucat][��]: ������Ⱥ " + to_string(group_id) + u8"����Ϣ��";
		tmp += msg;
		std::cout << tmp << std::endl;
		send(j);
	}

	void send_message(Target tar, const std::string msg) {
		if (tar.type == Target::Type::GROUP) {
			send_group_message(tar, msg);
		}
		else if (tar.type == Target::Type::PRIVATE) {
			send_private_message(tar, msg);
		}
	}

	Type Parser(std::string rawstr, Target* target, GroupSender* sender, Request* request) {
		if (rawstr.find("user_id") != std::string::npos) {
			cqhttp_api::Target t;
			json j = json::parse(rawstr);
			cqhttp_api::Type type;
			if (j["post_type"].get<std::string>() == "message") {
				type = cqhttp_api::Type::MESSAGE;
			}
			else if (j["post_type"].get<std::string>() == "request") {
				type = cqhttp_api::Type::REQUEST;
			}
			else return cqhttp_api::Type::INVALID;
			if (type == cqhttp_api::Type::MESSAGE) {
				cqhttp_api::Target tar;
				cqhttp_api::GroupSender sdr;
				json jm = json::parse(rawstr)["sender"];
				if (j["message_type"].get<std::string>() == "private") {
					tar.type = cqhttp_api::Target::Type::PRIVATE;
				}
				else if (j["message_type"].get<std::string>() == "group") {
					tar.type = cqhttp_api::Target::Type::GROUP;
					tar.group_id = j["group_id"].get<int64_t>();
					sdr.card = jm["card"].get<std::string>();
					sdr.title = jm["title"].get<std::string>();
				}
				sdr.age = jm["age"].get<int>();
				sdr.nickname = jm["nickname"].get<std::string>();
				tar.user_id = j["user_id"].get<int64_t>();
				tar.time = j["time"].get<int64_t>();
				tar.message = j["message"].get<std::string>();
				std::string msg;
				if (tar.type == cqhttp_api::Target::Type::PRIVATE) {
					msg += u8"[" + utils::unixTime2Str(tar.time) + u8"] [osucat][��]: ���� " + to_string(tar.user_id) + u8" ����Ϣ��";
					msg += tar.message;
				}
				else if (tar.type == cqhttp_api::Target::Type::GROUP) {
					msg += u8"[" + utils::unixTime2Str(tar.time) + u8"] [osucat][��]: Ⱥ " + to_string(tar.group_id) + u8" �� " + to_string(tar.user_id) + u8" ����Ϣ��";
					msg += tar.message;
				}
				std::cout << msg << std::endl;
				*target = tar;
				*sender = sdr;
				return type;
			}
			else if (type == cqhttp_api::Type::REQUEST) {
				cqhttp_api::Request r;
				cqhttp_api::Request::Type rt;
				std::string msg;
				r.message = j["comment"].get<std::string>();
				r.user_id = j["user_id"].get<int64_t>();
				r.flag = j["flag"].get<std::string>();
				r.time = j["time"].get<int64_t>();
				if (j["request_type"].get<std::string>() == "friend") {
					rt = cqhttp_api::Request::Type::FRIEND;
					r.type = cqhttp_api::Request::Type::FRIEND;
					msg += u8"[" + utils::unixTime2Str(r.time) + u8"] [osucat][��]: �յ������û� " + to_string(r.user_id) + u8" �ĺ�������";
					if (!r.message.empty())msg += u8"������Ϣ��" + r.message;
				}
				else if (j["request_type"].get<std::string>() == "group") {
					rt = cqhttp_api::Request::Type::GROUP;
					r.type = cqhttp_api::Request::Type::GROUP;
					msg += u8"[" + utils::unixTime2Str(r.time) + u8"] [osucat][��]: �յ������û� " + to_string(r.user_id) + u8" ��Ⱥ����";
					if (!r.message.empty())msg += u8"������Ϣ��" + r.message;
				}
				std::cout << msg << std::endl;
				*request = r;
				return type;
			}
		}
		return cqhttp_api::Type::INVALID;
	}
}
#endif