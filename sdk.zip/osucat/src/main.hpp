#pragma once
#ifndef CQHTTP_API_MAIN
#define CQHTTP_API_MAIN

using namespace osucat;

namespace cqhttp_api {
	class Event {
	public:
		static void on_message(const Target target, const GroupSender sender) {
			//gwsp->close();
			//echo(target, sender);
		}

		static void on_request(const Request request) {

		}
	};
}
#endif

