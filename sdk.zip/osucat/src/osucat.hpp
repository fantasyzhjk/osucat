#pragma once
#ifndef OC_MAIN_HPP
#define OC_MAIN_HPP
using namespace std;
using namespace cqhttp_api;

namespace osucat {

	void echo(const Target tar, const GroupSender sdr) {
		send_message(tar, tar.message);
	}

}

#endif